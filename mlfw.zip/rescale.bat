java -cp ./lib/regression.jar;./lib/mlfw.jar;./lib/tools.jar;./lib/exception.jar; tm.mlfw.tools.Rescaler %1 %2 %3
