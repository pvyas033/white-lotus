from typing import List, override
from typing import Optional

from set.abstract_set import AbstractSet
from datatype import String

class StringSet(AbstractSet[String]):
    
    def __init__(self, capacity: int = 16):
        self._data=[""] * capacity
        super().__init__(capacity, self._data)
    

    @override
    def validate_input(self, value) -> bool:
        return String.validate(value)