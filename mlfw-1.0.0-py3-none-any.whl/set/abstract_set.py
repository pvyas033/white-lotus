from typing import Generic, TypeVar, List

from exception.invalid_bound_exception import InvalidBoundException

T = TypeVar('T')

class AbstractSet(Generic[T]):
    
    def __init__(self, capacity: int = 16, data=None):
        self._size = 0
        if data is not None: 
            self._data = [None] * capacity
        else: 
            self._data=data

    def get(self, index: int) -> T:
        if index < 0 or index >= self._size:
            raise InvalidBoundException(f" {index} Index is out of bounds")
        return self._data[index]

    def validate_input(self, value: T) -> bool:
        return value is not None
    
    def add(self, value: T) -> bool:
        if self.validate_input(value) is not True:
            return False;
        
        if value in self._data[:self._size]:
            return False  

        if self._size >= len(self._data):
            self._data.extend([T] * (self._size // 2))

        self._data[self._size] = value
        self._size += 1
        return True

    def size(self) -> int:
        return self._size

    def __str__(self) -> str:
        if self._size == 0:
            return "\0"
        return "\n".join(filter(None, self._data[:self._size]))
