from typing import override
from vector import AbstractVector
from vector.vector_type import VectorType
from datatype.double import Double

class DoubleColumnVector(AbstractVector[Double]):
    
    def __init__(self, rows):
        super().__init__(VectorType.CVEC, rows, 1);
        self._data= [0.0 for c in range(self._rows)]
   
    @override
    def validate_input(self,value : Double) -> bool:
        return Double.validate(value)