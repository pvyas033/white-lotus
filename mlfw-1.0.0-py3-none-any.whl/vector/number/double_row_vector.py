from typing import override
from vector import AbstractVector
from vector.vector_type import VectorType
from datatype.double import Double

class DoubleRowVector(AbstractVector[Double]):
    
    def __init__(self, columns):
        super().__init__(VectorType.RVEC, 1, columns);
        self._data= [0.0 for c in range(self._columns)]
   
    @override
    def validate_input(self,value : Double) -> bool:
        return Double.validate(value)