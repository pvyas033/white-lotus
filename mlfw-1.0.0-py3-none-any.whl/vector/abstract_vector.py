from typing import Generic, TypeVar, override
from exception.invalid_bound_exception import InvalidBoundException
from vector.vector_type import VectorType


T = TypeVar('T')

class AbstractVector(Generic[T]):
    
    def __init__(self, type: VectorType, rows: int, columns: int):
        self._type=type
        self._rows=rows
        self._columns=columns
        
        if type is VectorType.CVEC:
            self._data= [None for r in range(rows)]
        
        if type is VectorType.RVEC:
            self._data= [None for c in range(columns)]
        
        self._size=len(self._data)
    
    def size(self):
        return self._size;

    def validate_input(self, value: T) -> bool:
        return value is not None
            
    def get_value(self, index: int) -> T:
        return self._data[index];

    def validate_index(self, index: int) -> bool:
        if index<0:
            raise InvalidBoundException(f"Invalid bounds index {index} can't be negative")
        if self._type is VectorType.CVEC and index>=self._rows:
            raise InvalidBoundException(f"Invalid bounds row {index} is out of bound")
        if self._type is VectorType.RVEC and index>=self._columns: 
            raise InvalidBoundException(f"Invalid bounds column {index} is out of bound")
        return True;
    
    def type(self) -> VectorType:
        return self._type;
        
    def set_value(self, index: int, value: T):
        if self.validate_index(index) is True and  self.validate_input(value) is True:
            self._data[index]=value;
    
    @override
    def __str__(self) -> str:
        if self._type is VectorType.CVEC:
            return '\n'.join([str(self._data[r]) for r in range(self._rows)])
        if self._type is VectorType.RVEC:
            return ','.join([str(self._data[c]) for c in range(self._columns)])
        
        return '\0';
