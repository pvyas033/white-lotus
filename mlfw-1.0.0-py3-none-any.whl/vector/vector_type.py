from enum import Enum

class VectorType(Enum):
    CVEC= "COLUMN_VECTOR"
    RVEC= "ROW_VECTOR"