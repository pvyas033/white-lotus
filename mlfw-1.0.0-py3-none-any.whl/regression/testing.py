import sys
from collections import deque
from exception.loading_exception import LoadingException
from matrix.number.double_matrix import DoubleMatrix
from operations import file_operations
from regression.training import Training
from vector.number.double_column_vector import DoubleColumnVector
from operations.matrix_operations import fill_double_matrix, copy_double_matrix, transpose_double_matrix, copy_double_column_vector
from operations.vector_operations import double_matrix_multiply_double_column_vector, get_double_column_vector_from_double_matrix
from exception.invalid_argument_exception import InvalidArgumentException
from exception.unknown_exception import UnknownException
from datatype.__datatype__ import DataType
from vector.vector_type import VectorType


class Testing:
    
    DATASET_FILE_NAME = None;
    RESULT_FILE_NAME = None;
    PARAMETER_FILE_NAME = None;
    
    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if not args or len(args) < 3:
            print("________________________________________________________________________\n")
            print("Usage: [tester datasetFileName resultFileName parameterFileName]")
            print("________________________________________________________________________\n")
            sys.exit(1)
    
        Testing.DATASET_FILE_NAME = args[0]
        Testing.RESULT_FILE_NAME = args[1]
        Testing.PARAMETER_FILE_NAME = args[2]
    
        if not Testing.DATASET_FILE_NAME or not Testing.PARAMETER_FILE_NAME or not Testing.PARAMETER_FILE_NAME:
            raise InvalidArgumentException("File names cannot be null or blank")
    
        Testing.test_it()
        print("______________________________________________________________________\n")
        print(f"Results are stored in: {Testing.RESULT_FILE_NAME}")
        print("______________________________________________________________________")
        
    @staticmethod
    def test_it():
        # Load dataset
        D = file_operations.csv_to_matrix(Testing.DATASET_FILE_NAME, DataType.DBL)
    
        # Initialize matrices and vectors
        I_rows, I_columns = D.get_rows_count(), D.get_columns_count()
        I = DoubleMatrix(I_rows, I_columns)
    
        # Fill the input matrix with 1.0 for x0
        fill_double_matrix(I, 0, I_rows - 1, 0, 0, 1.0)
    
        # Copy the dataset's first column into the input matrix's second column x1
        copy_double_matrix(D, I, 0, I_rows - 1, 0, I_columns - 2, 0, I_rows - 1, 1, I_columns - 1)
    
        # Load parameters
        m = file_operations.csv_to_vector(Testing.PARAMETER_FILE_NAME, VectorType.CVEC, DataType.DBL)
    
        # Perform matrix-vector multiplication
        P = double_matrix_multiply_double_column_vector(I, m)
    
        # Prepare the result matrix
        result_matrix = DoubleMatrix(D.get_rows_count(), D.get_columns_count() + 1)
        copy_double_matrix(D, result_matrix, 0, I_rows - 1, 0, I_columns - 1, 0, I_rows - 1, 0, I_columns - 1)
        copy_double_column_vector(P, result_matrix, 0, I_rows - 1, 0, I_rows-1, I_columns)
    
        # Write the result to a file
        file_operations.matrix_to_csv(result_matrix, Testing.RESULT_FILE_NAME)


if __name__ == "__main__":
    Testing.main()
    
