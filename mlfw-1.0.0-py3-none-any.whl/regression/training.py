import sys
import threading
import keyboard

from collections import deque
from exception.loading_exception import LoadingException
from matrix.number.double_matrix import DoubleMatrix
from operations import file_operations
from vector.number.double_column_vector import DoubleColumnVector
from operations.matrix_operations import fill_double_matrix, copy_double_matrix, transpose_double_matrix
from operations.vector_operations import double_matrix_multiply_double_column_vector, get_double_column_vector_from_double_matrix
from exception.invalid_argument_exception import InvalidArgumentException
from exception.unknown_exception import UnknownException
from datatype.__datatype__ import DataType

class Training:
    NUMBER_OF_ITERATIONS = -1
    DATASET_FILE_NAME = None
    LEARNING_RATE = 0.1
    HISTORY_SIZE = 0
    HISTORY_FILE_NAME = None
    STOP_FLAG = False
    GRAPH_FILE_NAME = None
    PARAMETERS_FILE_NAME = None

    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if not args or len(args) < 6:
            print("_______________________________________________________________________________________________________________________________________________\n")
            print("Usage : [trainer datasetFileName learningRate historySize historyFileName graphFileName parametersFileName numberOfIterations(OPTIONAL)]")
            print("Note  : If numberOfIterations(OPTIONAL) not provided then you can stop training by pressing escape \"esc\"\n");
            print("_______________________________________________________________________________________________________________________________________________\n")
            return
        
        try:
            Training.DATASET_FILE_NAME = args[0]
            if not Training.DATASET_FILE_NAME:
                raise InvalidArgumentException("datasetFileName can't be null or blank")
            Training.LEARNING_RATE = float(args[1])
            Training.HISTORY_SIZE = int(args[2])
            if Training.HISTORY_SIZE < 5:
                raise InvalidArgumentException("historySize should be >= 5")
            Training.HISTORY_FILE_NAME = args[3]
            if not Training.HISTORY_FILE_NAME:
                raise InvalidArgumentException("historyFileName can't be null or blank")
            Training.GRAPH_FILE_NAME = args[4]
            if not Training.GRAPH_FILE_NAME:
                raise InvalidArgumentException("graphFileName can't be null or blank")
            Training.PARAMETERS_FILE_NAME = args[5]
            if not Training.PARAMETERS_FILE_NAME:
                raise InvalidArgumentException("parametersFileName can't be null or blank")
            if len(args) == 7:
                Training.NUMBER_OF_ITERATIONS = int(args[6])
                if Training.NUMBER_OF_ITERATIONS < 0:
                    raise InvalidArgumentException("numberOfIterations can't be negative")
        except ValueError as e:
            raise LoadingException(f"Unable to load matrix file contains strings: {e}")

        try:
            train_thread = threading.Thread(target=Training.train_it)
            train_thread.start()

            if Training.NUMBER_OF_ITERATIONS == -1:
                keyboard.wait('escape')
                Training.STOP_FLAG=True

            train_thread.join()

        except Exception as e:
            raise UnknownException(f"An error occurred during training: {e}")


        print("______________________________________________________________________")
        print(f"History stored in    : {Training.HISTORY_FILE_NAME}")
        print(f"Parameters stored in : {Training.PARAMETERS_FILE_NAME}")
        print("______________________________________________________________________")
        print("Note: Above files will create only if there are no exceptions/errors")

    @staticmethod
    def train_it():
        import os

        D = file_operations.csv_to_matrix(Training.DATASET_FILE_NAME, DataType.DBL)
        I_rows = D.get_rows_count()
        I_columns = D.get_columns_count()

        #print(f"Dataset Matrix : {D}");
        
        A = get_double_column_vector_from_double_matrix(D, I_columns - 1)
        I = DoubleMatrix(I_rows, I_columns)

        fill_double_matrix(I, 0, I_rows - 1, 0, 0, 1.0)
        copy_double_matrix(D, I, 0, I_rows - 1, 0, I_columns - 2, 0, I_rows - 1, 1, I_columns - 1)

        H = DoubleMatrix(Training.HISTORY_SIZE, I_columns+1+1)
        itreationQ = deque()
        finalErrorQ = deque()
        mQ = deque()

        #print(f"Input Matrix : {I}");
        
        print(f"\nLeaning Rate : {Training.LEARNING_RATE}\n")
        IT = transpose_double_matrix(I)
        
        m = DoubleColumnVector(I_columns)
        for i in range(I_columns):
            m.set_value(i, 0.0)

        k = 0
        with open(Training.GRAPH_FILE_NAME, 'w') as graph_file:
            while not Training.STOP_FLAG:
                if k == Training.NUMBER_OF_ITERATIONS:
                    break

                P = double_matrix_multiply_double_column_vector(I, m)
                E = DoubleColumnVector(I_rows)
                for i in range(I_rows):
                    E.set_value(i, P.get_value(i) - A.get_value(i))

                ET = [E.get_value(i) for i in range(I_rows)]
                ETE = sum(ET[i] * E.get_value(i) for i in range(I_rows))
                final_error = ETE / (2.0 * I_rows)
                print(f"Iteration: {k+1} Error: {final_error:.10f}")
                graph_file.write(f"{k+1},{final_error:.15f}\n")

                if len(itreationQ) > Training.HISTORY_SIZE:
                    itreationQ.popleft()
                    finalErrorQ.popleft()
                    mQ.popleft()
                else:
                    itreationQ.append(k+1)
                    finalErrorQ.append(final_error)
                    mQ.append(m)
                
                file_operations.vector_to_csv(m, Training.PARAMETERS_FILE_NAME)

                ITE = double_matrix_multiply_double_column_vector(IT, E)
                TMP = DoubleColumnVector(I_columns)
                for i in range(I_columns):
                    TMP.set_value(i, (Training.LEARNING_RATE * (1.0 / I_rows)) * ITE.get_value(i))

                UM = DoubleColumnVector(I_columns)
                for i in range(I_columns):
                    UM.set_value(i, m.get_value(i) - TMP.get_value(i))

                m = UM
                k += 1

            for i in range(Training.HISTORY_SIZE):
                if itreationQ:
                    H.set_value(i, 0,itreationQ.popleft());
                    H.set_value(i, 1,finalErrorQ.popleft());
                    mR = mQ.popleft()
                    for j in range(mR.size()):
                        H.set_value(i, 2 + j, mR.get_value(j))

        file_operations.matrix_to_csv(H, Training.HISTORY_FILE_NAME)

if __name__ == "__main__":
    Training.main()
    
