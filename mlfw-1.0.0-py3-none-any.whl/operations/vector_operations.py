from matrix.number.double_matrix import DoubleMatrix
from vector import VectorType
from datatype import DataType
from vector import DoubleColumnVector
from exception import InvalidInputException
from vector import DoubleRowVector
from vector.abstract_vector import AbstractVector

def double_matrix_multiply_double_column_vector(matrix, vector):
    result = DoubleColumnVector(matrix.get_rows_count())
    for row in range(matrix.get_rows_count()):
        sum_value = 0.0
        for col in range(matrix.get_columns_count()):
            sum_value += matrix.get_value(row, col) * vector.get_value(col)
        result.set_value(row, sum_value)
    return result

def get_double_column_vector_from_double_matrix(matrix, column_index):
    vector = DoubleColumnVector(matrix.get_rows_count())
    for row in range(matrix.get_rows_count()):
        vector.set_value(row, matrix.get_value(row, column_index))
    return vector


def __create_vector__(vector_type: VectorType, data_type: DataType, size: int):
    
    if vector_type is None or data_type is None or size == 0 or size is None:
        raise InvalidInputException("Invalid Size: Vector size can't be zero or none")
    
    if vector_type is VectorType.CVEC:
        
        if data_type is DataType.DBL:
            return DoubleColumnVector(size)
    
    if vector_type is VectorType.RVEC:
        
        if data_type is DataType.DBL:
            return DoubleRowVector(size)

def transpose(vector: AbstractVector, data_type=DataType.DBL):
    
    transpose_vector=None 
    
    if vector.type() is VectorType.CVEC:
        transpose_vector=__create_vector__(VectorType.RVEC, data_type, vector.size())
        
    if vector.type() is VectorType.RVEC:
        transpose_vector=__create_vector__(VectorType.CVEC, data_type, vector.size())
        
    
    [transpose_vector.set_value(i, vector.get_value(i)) for i in range(vector.size())]
    
    return transpose_vector
    

def substract_double_column_vector(left_vector, right_vector):
    result_vector= DoubleColumnVector(left_vector.size())
    
    for i in range(left_vector.size()):
        result_vector.set_value(i, float(left_vector.get_value(i)) - float(right_vector.get_value(i)))

    return result_vector

def multiply_double_row_vector_with_double_column_vector(double_row_vector, double_column_vector):
    scalar = 0.0

    for i in range(double_row_vector.size()):
        scalar += float(double_row_vector.get_value(i)) * float(double_column_vector.get_value(i))

    return scalar

def multiply_double_column_vector_to_double_row_vector(double_column_vector, double_row_vector):
    rows = double_column_vector.size()
    cols = double_row_vector.size()
    matrix = DoubleMatrix(rows, cols)

    for i in range(rows):
        for j in range(cols):
            matrix.set_value(i, j, double_column_vector.get_value(i) * double_row_vector.get_value(j))

    return matrix

def mean(vector):
    sum_val = 0.0
    size = vector.size()
    
    for i in range(size):
        sum_val += float(vector.get_value(i))
    
    return sum_val / size

def fill_double_row_vector(double_row_vector, start, end, value):
    for i in range(start, end + 1):
        double_row_vector.set_value(i, value)

    return True

def fill_double_column_vector(double_column_vector, start, end, value):
    for i in range(start, end + 1):
        double_column_vector.set_value(i, value)

    return True
