import csv
import os
from exception.invalid_file_exception import InvalidFileException
from exception.invalid_operation_exception import InvalidOperationException
from exception.loading_exception import LoadingException
from exception.writing_exception import WritingException

from matrix.number.double_matrix import DoubleMatrix
from matrix.string.string_matrix import StringMatrix
from datatype.__datatype__ import DataType
from vector.vector_type import VectorType

from operations.matrix_operations import __create_matrix__
from operations.vector_operations import __create_vector__

def validate_file(file_path, want_to_create_new=False):
    if not file_path or len(file_path) <=0:
        raise InvalidFileException(f"Invalid File Path: \"{file_path}\" can't be empty or null");
    if not want_to_create_new and not os.path.exists(file_path):
        raise InvalidFileException(f"Invalid File Path: \"{file_path}\" file doesn't exist");
    if not want_to_create_new and os.path.getsize(file_path) == 0:
        raise InvalidFileException(f"Invalid File: \"{file_path}\" can't be empty");
    if not file_path.lower().endswith(".csv"):
        raise InvalidFileException(f"Invalid File: \"{file_path}\" should be csv file");
    return True;
    
def write_to_csv(data, file_path):
    try:
        validate_file(file_path, True)
    except InvalidFileException as i:
        raise WritingException(f"Exception while writing : {i}");

    with open(file_path, "w") as file:
        file.write(data);
    
def vector_to_csv(vector, file_path):
    try:
        validate_file(file_path, True)
    except InvalidFileException as i:
        raise WritingException(f"Exception while writing : {i}");

    with open(file_path, "w") as file:
        file.write(vector.__str__());

def matrix_to_csv(matrix, file_path):
    try:
        validate_file(file_path, True)
    except InvalidFileException as i:
        raise WritingException(f"Exception while writing : {i}");

    with open(file_path, "w") as file:
        file.write(matrix.__str__());

def csv_to_vector(file_path, vector_type, data_type=DataType.STR):
    
    try: 
        validate_file(file_path)
    except InvalidFileException as i:
        raise LoadingException(f"Exception while loading : {i}");
    
    with open(file_path, 'r') as file:
        
        reader = csv.reader(file)
        rows=list(reader)
        row_count=len(rows)
        column_count=len(rows[0]);
        size=max(row_count, column_count);
        index=0;
        
        
        if (vector_type is VectorType.CVEC and column_count != 1) or (vector_type is VectorType.RVEC and row_count != 1):
            raise InvalidOperationException(f"Invalid operatoin: {vector_type} is not competible with file {file_path}")
        
        vector=__create_vector__(vector_type, data_type, size)                
        
        try:
            for r in range(row_count):
                for c in range(column_count):
                    if data_type is DataType.DBL:
                        vector.set_value(index, float(rows[r][c]))
                    if data_type is DataType.STR:
                        vector.set_value(index, str(rows[r][c]))
                    
                    index=index+1;
        except ValueError as ve:
            raise LoadingException(f"Exceotion while loading : {ve}")

    return vector;
    
                         
    
def csv_to_matrix(file_path, data_type=DataType.STR):
    
    try: 
        validate_file(file_path)
    except InvalidFileException as i:
        raise LoadingException(f"Exception while loading : {i}");
    
    with open(file_path, 'r') as file:
        
        reader = csv.reader(file)
        rows=list(reader)
        row_count=len(rows)
        column_count=len(rows[0]);
        
        matrix=__create_matrix__(row_count, column_count, data_type);
         
        try:
            for r in range(row_count):
                for c in range(column_count):
                    if data_type is DataType.DBL:
                        matrix.set_value(r,c, float(rows[r][c]))
                    if data_type is DataType.STR:
                        matrix.set_value(r,c, str(rows[r][c]))
        except ValueError as ve:
            raise LoadingException(f"Exceotion while loading : {ve}")
        
        return matrix;
        

            
            