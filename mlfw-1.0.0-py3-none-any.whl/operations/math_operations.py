import random

from exception.invalid_bound_exception import InvalidBoundException

def random_number_in_range(start, end):
    if end < start:
        raise InvalidBoundException(f"start {start} cannot be greater than end {end}")

    nextnum = random.randint(0, 2**31 - 1)  # Using a large range for randint
    nextnummod = nextnum % (end - start + 1)

    if nextnummod < start:
        nextnummod *= -1

    randomnuminrange = nextnummod + start

    return randomnuminrange