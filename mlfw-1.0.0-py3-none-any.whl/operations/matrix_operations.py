from datatype.__datatype__ import DataType
from exception.invalid_input_exception import InvalidInputException
from matrix.number.double_matrix import DoubleMatrix
from matrix.string.string_matrix import StringMatrix
from operations.math_operations import random_number_in_range


def fill_double_matrix(matrix, start_row, end_row, start_col, end_col, value):
    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            matrix.set_value(row, col, value)

def copy_double_column_vector(source_column_vector, target_matrix, source_start_row, source_end_row,
                               target_start_row, target_end_row, target_column_index):
    for i, j in zip(range(source_start_row, source_end_row + 1), range(target_start_row, target_end_row + 1)):
        target_matrix.set_value(j, target_column_index, source_column_vector.get_value(i))


def copy_double_matrix(source: DoubleMatrix, target: DoubleMatrix, source_start_row, source_end_row, source_start_col, source_end_col,
                       target_start_row, target_end_row, target_start_col, target_end_col):
    for row in range(source_start_row, source_end_row + 1):
        for col in range(source_start_col, source_end_col + 1):
            target.set_value(row - source_start_row + target_start_row, col - source_start_col + target_start_col, float(source.get_value(row, col)))


def get_maximum_from_double_matrix(double_matrix, start_row, end_row, start_column, end_column):
    max_value = double_matrix.get_value(start_row, start_column)

    for r in range(start_row, end_row + 1):
        for c in range(start_column, end_column + 1):
            if max_value < double_matrix.get_value(r, c):
                max_value = double_matrix.get_value(r, c)

    return max_value


def get_minimum_from_double_matrix(double_matrix, start_row, end_row, start_column, end_column):
    min_value = double_matrix.get_value(start_row, start_column)

    for r in range(start_row, end_row + 1):
        for c in range(start_column, end_column + 1):
            if min_value > double_matrix.get_value(r, c):
                min_value = double_matrix.get_value(r, c)

    return min_value
    

def transpose_double_matrix(matrix):
    rows = matrix.get_columns_count()
    columns = matrix.get_rows_count()
    transpose = DoubleMatrix(rows, columns)
    for row in range(rows):
        for col in range(columns):
            transpose.set_value(row, col, matrix.get_value(col, row))
    return transpose

def shuffle_double_matrix(matrix: DoubleMatrix, times):    
    rows = matrix.get_rows_count()
    for i in range(times):
        for j in range(rows - 3):
            matrix.swap(j, random_number_in_range(j, rows - 1))

    return matrix

def __create_matrix__(rows: int, columns: int, data_type=DataType.STR):
    
    if data_type is None or rows < 0 or columns < 0:
        raise InvalidInputException("Invalid rows/columns: Matrix rows or columns count can't be zero or none")
    
    if data_type is DataType.STR:
        return StringMatrix(rows, columns)
    if data_type is DataType.DBL:
        return DoubleMatrix(rows, columns)