import sys
from datatype.__datatype__ import DataType
from exception.invalid_argument_exception import InvalidArgumentException
from matrix import DoubleMatrix
from operations import file_operations, matrix_operations
from operations.file_operations import csv_to_matrix

class Scaler:
    INPUT_FILE_NAME = None
    OUTPUT_FILE_NAME = None
    start_column = 0
    end_column = 0
    MINMAX_FILE_NAME = None
    use_minmax = False

    @staticmethod
    def validate_args(args):
        if len(args) < 6:
            print("__________________________________________________________________________________________________________________________________\n")
            print("Usage: [scalerminmax inputFileName outputFileName startColumn endColumn minmaxFileName wantToScaleWithProvidedMinMax(Y/N)]")
            print("__________________________________________________________________________________________________________________________________\n")
            return False
        return True

    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if not Scaler.validate_args(args):
            return

        Scaler.INPUT_FILE_NAME = args[0]
        if not Scaler.INPUT_FILE_NAME or Scaler.INPUT_FILE_NAME.strip() == "":
            raise InvalidArgumentException("inputFileName can't be null or blank")

        Scaler.OUTPUT_FILE_NAME = args[1]
        if not Scaler.OUTPUT_FILE_NAME or Scaler.OUTPUT_FILE_NAME.strip() == "":
            raise InvalidArgumentException("outputFileName can't be null or blank")

        try:
            Scaler.start_column = int(args[2])
            Scaler.end_column = int(args[3])
        except ValueError:
            raise InvalidArgumentException("startColumn and endColumn are invalid")

        Scaler.MINMAX_FILE_NAME = args[4]
        if not Scaler.MINMAX_FILE_NAME or Scaler.MINMAX_FILE_NAME.strip() == "":
            raise InvalidArgumentException("minmaxFileName can't be null or blank")

        minmax_use = args[5]
        if not minmax_use or minmax_use.strip() == "":
            raise InvalidArgumentException("wantToScaleWithProvidedMinMax can't be null or blank")

        Scaler.use_minmax = minmax_use.lower().startswith('y')

        Scaler.run()

    @staticmethod
    def run():
        input_matrix = csv_to_matrix(Scaler.INPUT_FILE_NAME, DataType.DBL)

        print("______________________________________________________________________\n")
        if not Scaler.use_minmax:
            scaled_matrix = Scaler.scale_double_minmax(input_matrix, 0, input_matrix.get_rows_count() - 1, Scaler.start_column, Scaler.end_column, Scaler.MINMAX_FILE_NAME)
            print(f"Min and max of each column is stored in: {Scaler.MINMAX_FILE_NAME}")
        else:
            minmax_matrix = csv_to_matrix(Scaler.MINMAX_FILE_NAME, DataType.DBL)
            scaled_matrix = Scaler.scale_double_minmax_from_minmax_matrix(input_matrix, 0, input_matrix.get_rows_count() - 1, Scaler.start_column, Scaler.end_column, minmax_matrix)

        file_operations.matrix_to_csv(scaled_matrix, Scaler.OUTPUT_FILE_NAME)
        print(f"Scaled inputs are stored in: {Scaler.OUTPUT_FILE_NAME}")
        print("______________________________________________________________________\n")

    @staticmethod
    def scale_double_minmax(double_matrix, start_row, end_row, start_column, end_column, minmax_file_name):
        
        new_matrix = DoubleMatrix(end_row - start_row + 1, end_column - start_column + 1)
        n_columns = new_matrix.get_columns_count()

        min_vals = [matrix_operations.get_minimum_from_double_matrix(double_matrix, start_row, end_row, c, c) for c in range(start_column, end_column + 1)]
        max_vals = [matrix_operations.get_maximum_from_double_matrix(double_matrix, start_row, end_row, c, c) for c in range(start_column, end_column + 1)]

        for r in range(start_row, end_row + 1):
            for c in range(start_column, end_column + 1):
                value = double_matrix.get_value(r, c)
                scaled_value = (value - min_vals[c - start_column]) / (max_vals[c - start_column] - min_vals[c - start_column])
                new_matrix.set_value(r - start_row, c - start_column, scaled_value)

        minmax_matrix = DoubleMatrix(2, n_columns)
        for c in range(n_columns):
            minmax_matrix.set_value(0, c, min_vals[c])
            minmax_matrix.set_value(1, c, max_vals[c])

        file_operations.matrix_to_csv(minmax_matrix, minmax_file_name)
        return new_matrix

    @staticmethod
    def scale_double_minmax_from_minmax_matrix(double_matrix, start_row, end_row, start_column, end_column, minmax_matrix):
        
        new_matrix = DoubleMatrix(end_row - start_row + 1, end_column - start_column + 1)

        for r in range(start_row, end_row + 1):
            for c in range(start_column, end_column + 1):
                min_val = minmax_matrix.get_value(0, c - start_column)
                max_val = minmax_matrix.get_value(1, c - start_column)
                value = double_matrix.get_value(r, c)
                scaled_value = (value - min_val) / (max_val - min_val)
                new_matrix.set_value(r - start_row, c - start_column, scaled_value)

        return new_matrix

if __name__ == "__main__":
    Scaler.main()
