from ssl import HAS_NEVER_CHECK_COMMON_NAME
import sys
import argparse
from datatype.__datatype__ import DataType

from exception import InvalidArgumentException, InvalidBoundException
from matrix import StringMatrix
from operations.file_operations import csv_to_matrix, matrix_to_csv, write_to_csv
from set.string.string_set import StringSet

class Encoder:
    DATASET_FILE_NAME = None
    OUTPUT_FILE_NAME = None
    columns_to_encode = None
    has_header = False

    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if args is None or len(args) < 4:
            print("_____________________________________________________________________________________________\n")
            print("Usage : [encoder datasetFileName outputFileName \"comma separated columns\" hasHeader]")
            print("_____________________________________________________________________________________________\n")
            return

        Encoder.DATASET_FILE_NAME = args[0]
        if not Encoder.DATASET_FILE_NAME:
            raise InvalidArgumentException("datasetFileName can't be null or blank")

        Encoder.OUTPUT_FILE_NAME = args[1]
        if not Encoder.OUTPUT_FILE_NAME:
            raise InvalidArgumentException("outputFileName can't be null or blank")

        columns = args[2]        
        if not columns:
            raise InvalidArgumentException("columnsArray can't be null or blank")
        Encoder.columns_to_encode = list(map(int, columns.split(',')))

        has_header_input = args[3]
        if not has_header_input:
            raise InvalidArgumentException("hasHeader can't be null or blank")
        Encoder.has_header = has_header_input.lower().startswith('y')


        Encoder.encode_one_hot_code(
            Encoder.DATASET_FILE_NAME,
            Encoder.OUTPUT_FILE_NAME,
            Encoder.columns_to_encode,
            Encoder.has_header
        )
        
        print("______________________________________________________________________\n")
        print(f"One encoded values are stored in: {Encoder.OUTPUT_FILE_NAME}")
        print("______________________________________________________________________\n")

    @staticmethod
    def encode_one_hot_code(dataset_file_name, output_file_name, columns, has_header):
        
        if not dataset_file_name or not output_file_name or not columns:
            raise InvalidArgumentException("File names and columns can't be null or blank")

        dataset_file = dataset_file_name
        output_file = output_file_name

        string_matrix = csv_to_matrix(dataset_file, DataType.STR)
        
        d_rows = string_matrix.get_rows_count()
        d_columns = string_matrix.get_columns_count()
        start_index = 1 if has_header else 0

        for i in columns:
            if i < 0 or i >= d_columns:
                raise InvalidBoundException(f"Given columns {columns} are out of bound")

        sets = [StringSet() for _ in columns]

        index=0;
        for col in columns:
            for j in range(start_index, d_rows):
                value = string_matrix.get_value(j, col)
                added = sets[index].add(value)
            index+=1;
       
        
        header_string = ""
        data = list()

        if has_header:
            for i in range(d_columns):
                is_present = False
                for j, col in enumerate(columns):
                    if i == col:
                        is_present = True
                        for k in range(sets[j].size()):
                            header_string += f"{string_matrix.get_value(0, i)}_{sets[j].get(k)}"
                            if k + 1 != sets[j].size():
                                header_string += ","
                        break
                if not is_present:
                    header_string += string_matrix.get_value(0, i)
                if i + 1 != d_columns:
                    header_string += ","

        data.append(header_string)

        for r in range(start_index, d_rows):
            data_line = ""
            for c in range(d_columns):
                is_present = False
                for j, col in enumerate(columns):
                    if c == col:
                        is_present = True
                        for k in range(sets[j].size()):
                            if string_matrix.get_value(r, c) == sets[j].get(k):
                                data_line += "1"
                            else:
                                data_line += "0"
                            if k + 1 != sets[j].size():
                                data_line += ","
                        break
                if not is_present:
                    data_line += string_matrix.get_value(r, c)
                if c + 1 != d_columns:
                    data_line += ","
            data.append(data_line)
        
        write_to_csv("\n".join([str(data[i]) for i in range(len(data))]), output_file)

if __name__ == "__main__":
    Encoder.main()
