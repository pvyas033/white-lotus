import sys

from exception.invalid_argument_exception import InvalidArgumentException
from matrix.number.double_matrix import DoubleMatrix
from vector.number.double_column_vector import DoubleColumnVector
from vector.number.double_row_vector import DoubleRowVector
from operations.file_operations import (
    csv_to_matrix,
    csv_to_vector,
)
from operations.vector_operations import (
    transpose,
    get_double_column_vector_from_double_matrix, 
    substract_double_column_vector, 
    multiply_double_row_vector_with_double_column_vector,
    mean,
    fill_double_column_vector
)

class Scorer:
    RESULT_DATASET_FILE_NAME = None

    @staticmethod
    def main():
        args=sys.argv[1:]
        if args is None or len(args) < 1:
            print("______________________________________\n")
            print("Usage : [scorer resultFileName]")
            print("______________________________________\n")
            return

        Scorer.RESULT_DATASET_FILE_NAME = args[0]
        if Scorer.RESULT_DATASET_FILE_NAME is None or Scorer.RESULT_DATASET_FILE_NAME.strip() == "":
            raise InvalidArgumentException("resultFileName can't be null or blank")
        
        Scorer.score(Scorer.RESULT_DATASET_FILE_NAME)

    @staticmethod
    def score(file_path):
        predictions_matrix = csv_to_matrix(file_path)

        if predictions_matrix is None or predictions_matrix.get_rows_count() == 0:
            return

        A = get_double_column_vector_from_double_matrix(predictions_matrix, predictions_matrix.get_columns_count() - 2)
        P = get_double_column_vector_from_double_matrix(predictions_matrix, predictions_matrix.get_columns_count() - 1)

        R = substract_double_column_vector(A, P)
        
        RT = transpose(R)

        RTR = multiply_double_row_vector_with_double_column_vector(RT, R)

        mean_of_actuals = mean(A)
        
        M = DoubleColumnVector(A.size())

        fill_double_column_vector(M, 0, A.size() - 1, mean_of_actuals)
        AM = substract_double_column_vector(A, M)
        
        AMT = transpose(AM)
        
        AMTAM = multiply_double_row_vector_with_double_column_vector(AMT, AM)

        SSR = RTR
        SST = AMTAM

        #print(f"SSR {SSR}")
        #print(f"SST {SST}")
        r2score = 1 - (SSR / SST)
        
        print("______________________________________________________________________\n")
        print(f"R2SCORE of the test is : {r2score:45.15f}")
        print("______________________________________________________________________")

if __name__ == "__main__":
    Scorer.main()
