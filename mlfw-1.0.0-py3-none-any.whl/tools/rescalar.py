import sys
from datatype.__datatype__ import DataType
from exception.invalid_argument_exception import InvalidArgumentException
from matrix import DoubleMatrix
from operations import file_operations
from operations.file_operations import csv_to_matrix

class Rescaler:
    INPUT_FILE_NAME = None
    OUTPUT_FILE_NAME = None
    MINMAX_FILE_NAME = None

    @staticmethod
    def validate_args(args):
        if len(args) < 3:
            print("_____________________________________________________________________\n")
            print("Usage: [rescaler inputFileName outputFileName minmaxFileName]")
            print("_____________________________________________________________________\n")
            return False
        return True

    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if not Rescaler.validate_args(args):
            return

        Rescaler.INPUT_FILE_NAME = args[0]
        if not Rescaler.INPUT_FILE_NAME or Rescaler.INPUT_FILE_NAME.strip() == "":
            raise InvalidArgumentException("inputFileName can't be null or blank")

        Rescaler.OUTPUT_FILE_NAME = args[1]
        if not Rescaler.OUTPUT_FILE_NAME or Rescaler.OUTPUT_FILE_NAME.strip() == "":
            raise InvalidArgumentException("outputFileName can't be null or blank")

        Rescaler.MINMAX_FILE_NAME = args[2]
        if not Rescaler.MINMAX_FILE_NAME or Rescaler.MINMAX_FILE_NAME.strip() == "":
            raise InvalidArgumentException("minmaxFileName can't be null or blank")

        Rescaler.run()

    @staticmethod
    def run():
        double_matrix = csv_to_matrix(Rescaler.INPUT_FILE_NAME, DataType.DBL)
        minmax_matrix = csv_to_matrix(Rescaler.MINMAX_FILE_NAME, DataType.DBL)

        D_rows = double_matrix.get_rows_count()
        D_columns = double_matrix.get_columns_count()

        min_val = minmax_matrix.get_value(0, minmax_matrix.get_columns_count() - 1)
        max_val = minmax_matrix.get_value(1, minmax_matrix.get_columns_count() - 1)

        for r in range(D_rows):
            for c in range(D_columns - 2, D_columns):
                scaled_value = double_matrix.get_value(r, c)
                value = (scaled_value * (max_val - min_val)) + max_val
                double_matrix.set_value(r, c, value)

        file_operations.matrix_to_csv(double_matrix, Rescaler.OUTPUT_FILE_NAME)

        print("______________________________________________________________________\n")
        print(f"Rescaled values are stored in: {Rescaler.OUTPUT_FILE_NAME}")
        print("______________________________________________________________________\n")

if __name__ == "__main__":
    Rescaler.main()
