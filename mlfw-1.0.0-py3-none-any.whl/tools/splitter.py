from datatype.__datatype__ import DataType
from exception.invalid_argument_exception import InvalidArgumentException
from matrix.number.double_matrix import DoubleMatrix
from operations.file_operations import csv_to_matrix, validate_file, matrix_to_csv
from operations.matrix_operations import shuffle_double_matrix, copy_double_matrix

import sys

class Splitter:
    DATASET_FILE_NAME = None
    TRAINING_DATASET_FILE_NAME = None
    TESTING_DATASET_FILE_NAME = None
    minor_percentage = 0

    @staticmethod
    def main():
        
        args=sys.argv[1:]
        if args is None or len(args) < 4:
            print("_______________________________________________________________________________________________________\n")
            print("Usage : [splitter datasetFileName trainingDatasetFileName testingDatasetFileName minorPercentage]")
            print("_______________________________________________________________________________________________________\n")
            return

        Splitter.DATASET_FILE_NAME = args[0]
        if Splitter.DATASET_FILE_NAME is None or Splitter.DATASET_FILE_NAME.strip() == "":
            raise InvalidArgumentException("datasetFileName can't be null or blank")

        Splitter.TRAINING_DATASET_FILE_NAME = args[1]
        if Splitter.TRAINING_DATASET_FILE_NAME is None or Splitter.TRAINING_DATASET_FILE_NAME.strip() == "":
            raise InvalidArgumentException("trainingDatasetFileName can't be null or blank")

        Splitter.TESTING_DATASET_FILE_NAME = args[2]
        if Splitter.TESTING_DATASET_FILE_NAME is None or Splitter.TESTING_DATASET_FILE_NAME.strip() == "":
            raise InvalidArgumentException("testingDatasetFileName can't be null or blank")

        try:
            Splitter.minor_percentage = int(args[3])
        except ValueError as e:
            raise InvalidArgumentException("minorPercentage is invalid", e)

        Splitter.create_training_and_testing_dataset_file(
            Splitter.DATASET_FILE_NAME, 
            Splitter.TRAINING_DATASET_FILE_NAME, 
            Splitter.TESTING_DATASET_FILE_NAME, 
            Splitter.minor_percentage
        )

    @staticmethod
    def create_training_and_testing_dataset_file(dataset_file, training_file_path, testing_file_path, minor_percentage):
        
        if not validate_file(dataset_file):
            return False

        if training_file_path is None or testing_file_path is None or training_file_path.strip() == "" or testing_file_path.strip() == "":
            raise InvalidArgumentException("file names can't be null or blank")

        if minor_percentage < 0 or minor_percentage > 50:
            raise InvalidArgumentException("minor percentage should be less than 50")

        matrix = csv_to_matrix(dataset_file, DataType.DBL)

        #print(matrix)
        
        shuffled_matrix = shuffle_double_matrix(matrix, 10)

        rows = shuffled_matrix.get_rows_count()
        columns = shuffled_matrix.get_columns_count()

        minor_rows = int((minor_percentage * rows) /100)
        training_matrix_rows = rows - minor_rows
        testing_matrix_rows = minor_rows

        training_matrix = DoubleMatrix(training_matrix_rows, columns)
        testing_matrix = DoubleMatrix(testing_matrix_rows, columns)
        #print(shuffled_matrix)
  

        copy_double_matrix(shuffled_matrix, testing_matrix, 0, minor_rows - 1, 0, columns - 1, 0, testing_matrix_rows - 1, 0, columns - 1)
        copy_double_matrix(shuffled_matrix, training_matrix, minor_rows, rows - 1, 0, columns - 1, 0, training_matrix_rows - 1, 0, columns - 1)

        matrix_to_csv(training_matrix, training_file_path)
        matrix_to_csv(testing_matrix, testing_file_path)

        print("______________________________________________________________________\n")
        print(f"Training dataset created : {training_file_path}")
        print(f"Testing dataset created  : {testing_file_path}")
        print("______________________________________________________________________")

        return True

if __name__ == "__main__":
    Splitter.main()
