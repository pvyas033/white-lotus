
class InvalidBoundException(Exception):
    def __init__(self, message="Index out of bound exception"):
        super().__init__(message);