
class InvalidOperationException(Exception):
    def __init__(self, message="Invalid operation"):
        super().__init__(message);