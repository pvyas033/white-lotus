
class InvalidFileException(Exception):
    def __init__(self, message="Invalid file exception"):
        super().__init__(message);