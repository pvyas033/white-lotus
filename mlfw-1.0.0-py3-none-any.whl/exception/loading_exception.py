
class LoadingException(Exception):
    def __init__(self, message="Exception while loading from"):
        super().__init__(message);