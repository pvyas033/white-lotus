
class InvalidArgumentException(Exception):
    def __init__(self, message="Invalid arugments"):
        super().__init__(message);