class InvalidInputException(Exception):
    def __init__(self, message="Invalid input"):
        super().__init__(message);