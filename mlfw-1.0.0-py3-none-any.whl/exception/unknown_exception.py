
class UnknownException(Exception):
    def __init__(self, message="Unknown Exception"):
        super().__init__(message);