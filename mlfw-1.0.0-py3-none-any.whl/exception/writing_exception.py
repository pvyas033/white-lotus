
class WritingException(Exception):
    def __init__(self, message="Exception while writing to file"):
        super().__init__(message);