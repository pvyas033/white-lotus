from exception.invalid_input_exception import InvalidInputException

class Double(float):
    
    @staticmethod
    def validate(value):
        
        try:
            float(value)
        except ValueError as ve:
            raise InvalidInputException(f"Invaid input \"{value}\" : value should be double/float :\n{ve}")
        
        return True

        