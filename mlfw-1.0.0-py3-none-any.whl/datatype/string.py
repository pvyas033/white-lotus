from exception.invalid_input_exception import InvalidInputException

class String(str):
    
    @staticmethod
    def validate(value):
        if isinstance(value, String) or isinstance(value, str):
            return True;
        else:
            raise InvalidInputException(f"Invaid input \"{value}\" : value should be str/String")