from enum import Enum

class DataType(Enum):
    DBL= "DOUBLE_DATA_TYPE"
    STR= "STRING_DATA_TYPE"