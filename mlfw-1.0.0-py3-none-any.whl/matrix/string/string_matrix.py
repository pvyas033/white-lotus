from typing import override
from datatype import String
from matrix.abstract_matrix import AbstractMatrix

class StringMatrix(AbstractMatrix[String]):
    
    def __init__(self, rows: int, columns: int):
        super().__init__(rows, columns)
        self.data= [["\0" for column in range(self._columns)] for row in range(self._rows)]
        

    @override
    def validate_input(self, value) -> bool:
        return String.validate(value)
        