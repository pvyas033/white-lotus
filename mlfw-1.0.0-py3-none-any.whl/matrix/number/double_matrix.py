from typing import override
from datatype import Double, double
from matrix.abstract_matrix import AbstractMatrix

class DoubleMatrix(AbstractMatrix[Double]):
    
    def __init__(self, rows: int, columns: int):
        self._rows=rows;
        self._columns=columns;
        self._data= [[0.0 for column in range(self._columns)] for row in range(self._rows)]
        super().__init__(self._rows, self._columns, self._data);

    @override
    def validate_input(self, value) -> bool:
        return Double.validate(value)
        
    
 