
from typing import TypeVar, Generic

from exception.invalid_bound_exception import InvalidBoundException


T = TypeVar('T')

class AbstractMatrix(Generic[T]):
    
    def __init__(self, rows: int, columns: int, data=None):
        self._rows=rows
        self._columns=columns
        if data is None: 
            self._data= [[None for column in range(columns)] for row in range(rows)]
        else:
            self._data=data;
    
    def get_value(self, row: int, column: int) -> T:
        return self._data[row][column];
    
    def validate_input(value: T) -> bool:
        return value is not None    
    
    def validate_index(self, row: int, column: int)-> bool:
        if row<0 or column <0:
            raise InvalidBoundException(f"Invalid bounds row {row} or column {column} can't be negative");
        if row>self._rows or column>self._columns: 
            raise InvalidBoundException(f"Invalid bounds row {row} or column {column} is out of bound");
        return True;

    def set_value(self, row: int, column: int, value: T):
        if self.validate_index(row, column) is True and self.validate_input(value) is True:
            self._data[row][column]=value;
    
    def get_rows_count(self):
        return self._rows
    
    def get_columns_count(self):
        return self._columns;
    
    def swap(self, row_one: int, row_rwo: int):
        self._data[row_one], self._data[row_rwo] =  self._data[row_rwo], self._data[row_one]

    def __str__(self) -> str:
        return '\n'.join([','.join([str(self._data[row][column]) for column in range(self._columns)]) for row in range(self._rows)])